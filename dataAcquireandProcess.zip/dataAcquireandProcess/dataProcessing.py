import pandas as pd
import numpy as np

# ========== 步骤 0：读取CSV文件 ==========
input_path = r"./raw_data/正常站立.csv"  # 输入文件路径
output_path = r"./processed_data/正常站立.csv"  # 输出文件路径

df = pd.read_csv(input_path, header=0)
# ========== 删除3σ离群值 ==========
def remove_3sigma_outliers_with_log(data):
    """删除离群值并记录被删行"""
    mask = pd.Series([True] * len(data), index=data.index)
    logs = []  # 记录被删行的索引和值

    for i in data.columns:
        col_mean = data[i].mean()
        col_std = data[i].std()
        if col_std == 0:
            continue
        lower = col_mean - 3 * col_std
        upper = col_mean + 3 * col_std
        # 记录本列导致的离群行
        outliers = data[~data[i].between(lower, upper, inclusive="both")]
        for row in outliers.index:
            logs.append({
                '行号': row,
                '列号': i,
                '值': data.loc[row, i],
                '原因': f'超出{lower:.2f}-{upper:.2f}'
            })
        mask &= data[i].between(lower, upper, inclusive="both")

    # 获取最终被删除的行（所有列综合判断）
    removed_df = data[~mask].copy()
    removed_df['删除原因'] = '3σ离群'
    return data[mask].reset_index(drop=True), removed_df


df_step1, removed_outliers = remove_3sigma_outliers_with_log(df)

# ========== 替换负值为均值并记录 ==========
replacement_logs = []  # 记录替换信息：行号、列号、原值、新值

for col in df_step1.columns:
    non_neg = df_step1[col][df_step1[col] >= 0]
    fill_value = round(non_neg.mean(), 2) if not non_neg.empty else 0.0

    # 查找负值位置
    negative_mask = df_step1[col] < 0
    negative_rows = df_step1[negative_mask]

    # 记录替换操作
    for idx in negative_rows.index:
        original_val = df_step1.loc[idx, col]
        replacement_logs.append({
            '行号': idx,
            '列号': col,
            '原值': original_val,
            '新值': fill_value
        })

    # 执行替换并保留两位小数
    df_step1[col] = np.where(
        negative_mask,
        fill_value,
        round(df_step1[col], 2))

    # ========== 保存结果 ==========
    df_step1.to_csv(output_path, index=False, header=False)

    # ========== 打印日志 ==========
    print("\n========== 被删除的离群行 ==========")
    if not removed_outliers.empty:
        print(f"共删除 {len(removed_outliers)} 行")
        print(removed_outliers.head())  # 打印前5行示例
    else:
        print("未删除任何行")

    print("\n========== 被替换的负值记录 ==========")
    if replacement_logs:
        print(f"共替换 {len(replacement_logs)} 个负值")
        log_df = pd.DataFrame(replacement_logs)
        print(log_df.head())  # 打印前5条记录
    else:
        print("未替换任何负值")

    print(f"\n处理完成！原始行数: {len(df)} → 处理后保留: {len(df_step1)} 行")