
import pandas as pd
import serial

# python接收arduino数据信号

# 创建串口对象，指定端口和波特率
ser = serial.Serial('COM5', 115200, timeout=0.5)
arduino_high = b'H'
arduino_low = b'L'

datasheet = []
rows = 0

# 读取原始数据并存入列表
try:
    while True:
        if ser.in_waiting > 0:
            raw_data = ser.readline().decode().strip()  # 读取一行数据
            data = [float(val) for val in raw_data.split(' ')]
            print(data)
            if data[0] > 0:
                datasheet.append(data)
                rows += 1
except KeyboardInterrupt:
    print('\n停止采集数据')
    print('采集的数据组:',rows)

finally:
    ser.close()
#print(datasheet)

cp = pd.DataFrame(datasheet)

try:
    old_cp = pd.read_csv(r"./raw_data/正常站立.csv")
except FileNotFoundError:
    old_cp = pd.DataFrame()

new_cp = pd.concat([old_cp, cp], ignore_index=True)
new_cp.to_csv(r"./raw_data/正常站立.csv",index=False)

