import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.path as mpath
import matplotlib.patches as patches
import matplotlib.tri as mtri
import matplotlib.colors as mcolors
from matplotlib.colors import BoundaryNorm
from scipy.spatial import Delaunay
from scipy.interpolate import RBFInterpolator
import ezdxf
from ezdxf.entities import Line
from collections import defaultdict


# ==================== DXF轮廓提取模块 ====================
def extract_line_based_contour(dxf_path: str, tolerance: float = 1e-6) -> np.ndarray:
    """从DXF文件中提取由LINE实体组成的闭合轮廓"""
    doc = ezdxf.readfile(dxf_path)
    lines = [i for i in doc.modelspace() if isinstance(i, Line)]
    if not lines:
        raise ValueError("DXF文件中未找到LINE实体")

    # 构建顶点连接关系
    point_map = defaultdict(list)
    for line in lines:
        start = round_point((line.dxf.start.x, line.dxf.start.y), tolerance)
        end = round_point((line.dxf.end.x, line.dxf.end.y), tolerance)
        point_map[start].append(end)
        point_map[end].append(start)

    # 寻找闭合环
    closed_loops = find_closed_loops(point_map, tolerance)
    if not closed_loops:
        raise ValueError("未找到由LINE组成的闭合轮廓")

    # 返回顶点最多的闭合环
    main_contour = max(closed_loops, key=lambda x: len(x))
    return np.array(main_contour)


def round_point(point: tuple, tolerance: float) -> tuple:
    """坐标规范化"""
    scale = 1 / tolerance
    return (round(point[0] * scale) / scale,
            round(point[1] * scale) / scale)


def find_closed_loops(point_map: dict, _tolerance: float) -> list:
    """深度优先搜索寻找闭合环"""
    visited = set()
    loops = []

    for start in point_map:
        if start in visited:
            continue

        path = []
        stack = [(start, None)]

        while stack:
            current, prev = stack.pop()

            if current in path:
                idx = path.index(current)
                loop = path[idx:] + [current]
                if len(loop) > 3:
                    loops.append(loop)
                continue

            if current in visited:
                continue

            visited.add(current)
            path.append(current)

            for neighbor in point_map.get(current, []):
                if neighbor != prev:
                    stack.append((neighbor, current))
    return loops


def transform_contour(points: np.ndarray,translate: tuple = (0, 0),scale: tuple = (1, 1)) -> np.ndarray:
    """
    对轮廓坐标进行几何变换

    参数：
        points: 原始轮廓坐标数组 (N, 2)
        translate: 平移量 (dx, dy)
        scale: 缩放因子 (sx, sy)
        center_scaling: 是否基于中心点缩放

    返回：
        变换后的坐标数组 (N, 2)
    """
    transformed= points.copy().astype(float)

    # 平移变换
    transformed+= np.array(translate)

    # 缩放变换(基于原点缩放)
    transformed*= np.array(scale)

    return transformed

# ==================== 应力云图主流程 ====================
def plot_stress_contour(dxf_file: str, sample_points, stress_values):
    """主函数：生成并绘制应力云图"""
    # 1. 提取闭合轮廓 -------------------------------------------------
    boundary = extract_line_based_contour(dxf_file)

    # 应用变换（平移到原点并缩小一半）
    boundary = transform_contour(
        boundary,
        translate=(-boundary.min(axis=0)),  # 平移到第一象限
        scale=(0.5, 0.5)
    )

    # 2. 验证轮廓闭合性 -----------------------------------------------
    contour_path = mpath.Path(boundary)

    # 3、转换手动输入采样点并验证位置合规性--------------------------------
    sample_points = np.array(sample_points)

    # 验证采样点位置
    is_inside= contour_path.contains_points(sample_points)
    invalid_points= sample_points[~is_inside]
    if len(invalid_points) > 0:
        error_msg= "以下点位于轮廓外部，请修正：\n"
        for i, (x, y) in enumerate(invalid_points):
            error_msg+= f"点{i + 1}: ({x:.2f}, {y:.2f})\n"
        raise ValueError(error_msg)
    print("所有采样点均位于轮廓内部")

    # 4. 处理压力值 -------------------------------------------------
    stress_values = np.array(stress_values)

    # 5. 生成插值网格 -----------------------------------------------
    x_min, x_max = boundary[:, 0].min(), boundary[:, 0].max()
    y_min, y_max = boundary[:, 1].min(), boundary[:, 1].max()
    xx, yy = np.meshgrid(np.linspace(x_min, x_max, 100),np.linspace(y_min, y_max, 100))
    grid_points = np.column_stack([xx.ravel(), yy.ravel()])

    # 6. RBF插值 --------------------------------------------------
    rbf = RBFInterpolator(sample_points, stress_values, kernel='linear')
    interpolated_stress = rbf(grid_points)
    interpolated_stress[interpolated_stress < 0] = 0

    # 7. 三角剖分 -------------------------------------------------
    tri = Delaunay(grid_points)
    triangulation = mtri.Triangulation(grid_points[:, 0], grid_points[:, 1], tri.simplices)

    # 8. 绘制云图 -------------------------------------------------
    plt.figure(figsize=(12, 8))
    ax = plt.gca()
    ax.set_aspect('equal')

    # 创建裁剪路径
    path = mpath.Path(boundary)
    patch = patches.PathPatch(path, facecolor='none', edgecolor='none')
    ax.add_patch(patch)

    # 绘制云图
    cmap = plt.get_cmap('jet').copy()
    cmap.set_over('#400000')
    dark_cmap = adjust_lightness(cmap, scale=1)
    levels = range(0,121,1)
    norm = BoundaryNorm(levels, ncolors = dark_cmap.N, clip=False)
    contour = ax.tricontourf(triangulation, interpolated_stress, levels, cmap=dark_cmap, norm=norm, extend='max')
    contour.set_clip_path(patch)

    # 绘制采样点
    #ax.scatter(sample_points[:, 0], sample_points[:, 1], c='red', s=50,edgecolors='white', label='采样点', zorder=3)

    # 绘制轮廓
    ax.plot(boundary[:, 0], boundary[:, 1], 'w-',linewidth=1.5)
    # 删除边框
    ax.axis('off')
    # 添加图例和标注
    plt.colorbar(contour, aspect=50, label='Pressure(KPa)', ticks=levels[::10])
    #plt.colorbar(contour, orientation='horizontal',shrink=0.8, aspect=50, label='Stress(KPa)', location='bottom')
    plt.show()



# ==================== 亮度调整函数 ====================
def adjust_lightness(cmap, scale=1.0):
    """
    调整颜色映射的亮度
    scale: 亮度缩放因子 (0.0-1.0)
    """
    # 获取原始颜色映射数据
    colors= cmap(np.linspace(0, 1, 256))
    # 转换为HSV颜色空间
    hsv= mcolors.rgb_to_hsv(colors[:, :3])
    # 调整亮度（V通道）
    hsv[:, 2] = np.clip(hsv[:, 2] * scale, 0, 1)
    # 转换回RGB并创建新颜色映射
    new_colors= mcolors.hsv_to_rgb(hsv)
    return mcolors.ListedColormap(new_colors, name=f"{cmap.name}_adjusted")

# ==================== 使用示例 ====================
if __name__ == "__main__":
    leftFoot_points = [(25,25),(30,55),(20,95),(45,95),(20,130),(50,130),(12,155),(35,155),(58,155),(40,175)]
    rightFoot_points = [(35,30),(35,55),(48,90),(23,90),(48,125),(20,125),(52,150),(30,150),(10,150),(30,175)]

    # 提取原始电容值数据，求均值
    cps = pd.read_csv(r"./raw_data/正常站立.csv")
    means_cp = cps.mean().tolist()
    #means_cp = [70.55,	9.14,	14.88,	13.77,	50.7,	20.24,	28.2,	13.14,	34.74,	90.96]
    # 根据拟合公式（分段函数）转换为压力值
    pressure = []
    for cp in means_cp:
        if cp < 2.6:
            pressure.append(0.01)
        elif 2.6 <=cp < 30:
            pressure.append(cp*0.07741-0.19897)
        elif 30<= cp < 157:
            pressure.append(cp*0.34216-9.83645)
        elif 157<= cp < 201:
            pressure.append(cp*1.64638-213.24416)
        else:
            pressure.append(cp*4.43465-776.47439)
    # 根据压强计算公式转换为压强值
    manual_stress_values = [round(i*1000/260, 2) for i in pressure]

    plot_stress_contour(r"./foot_contour/RightFoot.dxf",leftFoot_points,manual_stress_values)