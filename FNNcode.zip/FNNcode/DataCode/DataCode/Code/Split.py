import numpy as np

def split(data, ratios=(0.8, 0.1, 0.1), random_state=None):
    if random_state is not None:
        np.random.seed(random_state)  # 设置随机种子
    
    # 打乱数据
    shuffled_data = data[np.random.permutation(data.shape[0])]
    m = len(shuffled_data)
    
    # 计算分割点
    train_end = int(m * ratios[0])
    val_end = train_end + int(m * ratios[1])
    
    # 分割数据
    train_data = shuffled_data[:train_end]
    val_data = shuffled_data[train_end:val_end]
    test_data = shuffled_data[val_end:]
    
    return train_data, val_data, test_data
data=np.load("C:/Users/LENOVO/Desktop/Data/Dataset/All.npy")
tr,v,te=split(data,random_state=42)
np.save("C:/Users/LENOVO/Desktop/Data/Dataset/train.npy",tr)
np.save("C:/Users/LENOVO/Desktop/Data/Dataset/validation.npy",v)
np.save("C:/Users/LENOVO/Desktop/Data/Dataset/test.npy",te)