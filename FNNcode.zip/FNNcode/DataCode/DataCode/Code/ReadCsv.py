import numpy as np
import pandas as pd

def read_csv(file_path, label):

    data = pd.read_csv(file_path, header=0) 
    data = data.to_numpy()
    data = (data - data.min(axis=1, keepdims=True)) / (data.max(axis=1, keepdims=True) - data.min(axis=1, keepdims=True))
    labels = np.full((data.shape[0], 1), label)
    result = np.hstack((data, labels))

    return result

file_path = [
    "C:/Users/LENOVO/Desktop/Data/处理后/后倾站立.csv",
    "C:/Users/LENOVO/Desktop/Data/处理后/外翻站立.csv",
    "C:/Users/LENOVO/Desktop/Data/处理后/前倾站立.csv",
    "C:/Users/LENOVO/Desktop/Data/处理后/内翻站立.csv",
    "C:/Users/LENOVO/Desktop/Data/处理后/正常站立.csv"
]
data=[]
for i in range(5):
    data.append(read_csv(file_path[i], i))

data=np.vstack(data)
print(data[0,:])
print(data.shape)
np.save("C:/Users/LENOVO/Desktop/Data/Dataset/All.npy",data)
