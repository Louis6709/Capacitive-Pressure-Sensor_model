import torch.nn as nn

class FNN(nn.Module):
    def __init__(self, input_dim=10, output_dim=5):
        super(FNN, self).__init__()
        self.fc1 = nn.Linear(input_dim, 64)    # 输入层 → 隐藏层1
        self.fc2 = nn.Linear(64, 32)           # 隐藏层1 → 隐藏层2
        self.fc3 = nn.Linear(32, output_dim)   # 隐藏层2 → 输出层
        self.relu = nn.ReLU()                  # 激活函数

    def forward(self, x):
        x = self.relu(self.fc1(x))
        x = self.relu(self.fc2(x))
        x = self.fc3(x)  
        return x

if __name__ =='__main__':
    model=FNN()
    print(model)
