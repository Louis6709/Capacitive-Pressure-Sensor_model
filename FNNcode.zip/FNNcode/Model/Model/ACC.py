import matplotlib.pyplot as plt
import numpy as np
 
data = np.load("./loss.npy")
index = np.arange(data.shape[1])
 
plt.figure(figsize=(12, 6))
plt.plot(index, data[1], label='Train Accuracy', color='blue')
plt.plot(index, data[3], label='Validation Accuracy', color='green', linestyle='--')
plt.legend()
plt.title('Training Accuracy vs Validation Accuracy')
plt.xlabel('Epoch')
plt.ylabel('ACC(%)')
plt.grid(True, alpha=0.3)
plt.show()