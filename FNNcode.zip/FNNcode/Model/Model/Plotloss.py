import matplotlib.pyplot as plt
import numpy as np

data = np.load(r"./loss.npy")
index = np.arange(data.shape[1])
plt.figure(figsize=(12, 6))
plt.plot(index, data[0], label='train loss', color='blue')
plt.plot(index, data[2], label='validation loss', color='red')
plt.legend()

plt.title('Training Loss vs Validation Loss')
plt.xlabel('Epoch')
plt.ylabel('Loss')
plt.grid(True, alpha=0.3)
#plt.grid(False)
plt.show()