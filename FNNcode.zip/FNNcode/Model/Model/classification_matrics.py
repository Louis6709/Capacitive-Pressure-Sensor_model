import torch
import numpy as np

import sys
sys.path.append(r"Model/Model")

from FnnModel import FNN 
import torch.nn.functional as F 


device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
test_correct=0
test= np.load(r"../../DataCode/DataCode/Dataset/test.npy")[:, :10]
label=np.load(r"../..//DataCode/DataCode/Dataset/test.npy")[:,10]
test=torch.from_numpy(test).float().to(device)
label=torch.from_numpy(label).long().to(device)


model = FNN().to(device)
model.load_state_dict(torch.load(r"./model.pth", weights_only=True))
model.eval()
with torch.no_grad():
    outputs=model(test)

_, predicted = torch.max(outputs.data, 1)
pred_probs = F.softmax(outputs,1).tolist()
true_labels = label.cpu().numpy()
pred_labels = predicted.cpu().numpy()

from sklearn.metrics import (accuracy_score, precision_score, recall_score, f1_score,
roc_auc_score, log_loss, confusion_matrix)

# 计算分类指标
def calculate_classification_metrics(y_true, y_pred):
    metrics = {
        'Accuracy': accuracy_score(y_true, y_pred),
        'Precision (Macro)': precision_score(y_true, y_pred, average='macro'),
        'Recall (Macro)': recall_score(y_true, y_pred, average='macro'),
        'F1 (Macro)': f1_score(y_true, y_pred, average='macro'),
    }
    return metrics

results = calculate_classification_metrics(true_labels,pred_labels)
for name, value in results.items():
    print(f'{name}: {value:.4f}')

# 计算混淆矩阵
num_classes = len(np.unique(true_labels))  # 获取类别数量
cm = np.zeros((num_classes, num_classes), dtype=int)
for true, pred in zip(true_labels, pred_labels):
    cm[true][pred] += 1
 
correct_probs = np.diag(cm) / cm.sum(axis=1)  # 正确预测数 / 该类总样本数
 
# 计算每个类别的预测概率（所有格子）
# 将混淆矩阵中的每个元素除以该行的总和（该类别的总样本数）
row_sums = cm.sum(axis=1, keepdims=True)
# 避免除以零（如果某个类别没有样本）
row_sums[row_sums == 0] = 1
prob_matrix = cm / row_sums
 
# 将概率转换为字符串（保留2位小数）
annot = [[f"{prob*100:.2f}%" for prob in row] for row in prob_matrix]

print(annot)

# 计算AUC-ROC值(ovo)
auc_ovo_macro = roc_auc_score(
    true_labels,
    pred_probs,
    multi_class='ovo',    # 方法：One-vs-One
    average='macro'       # 平均方式：宏平均
)
print(f"OvO Macro AUC-ROC: {auc_ovo_macro:.4f}")

# 计算对数损失(Log-loss)
loss_multi = log_loss(true_labels, pred_probs)
print(f"Log Loss: {loss_multi:.4f}")
