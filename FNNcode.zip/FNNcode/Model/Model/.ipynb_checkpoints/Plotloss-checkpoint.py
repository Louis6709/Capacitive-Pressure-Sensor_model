import matplotlib.pyplot as plt
import numpy as np

data = np.load("C:/Users/LENOVO/Desktop/Model/loss.npy")
index = np.arange(data.shape[1])
plt.figure(figsize=(12, 6))
plt.plot(index, data[0], label='train loss', color='blue')
plt.plot(index, data[1], label='validation loss', color='red')
plt.legend()

plt.title('Loss')
plt.xlabel('epoch')
plt.ylabel('Value')

plt.grid(False)
plt.show()