import torch
from torch.utils.data import Dataset, DataLoader
import numpy as np
import torch.optim as optim
from tqdm import tqdm
from FnnModel import FNN
import torch.nn as nn

class dataset(Dataset):
    def __init__(self, data_path):
        self.data = np.load(data_path)[:,:10]
        self.labels = np.load(data_path)[:,10]

    def __len__(self):
        return len(self.data)

    def __getitem__(self, idx):
        x = torch.from_numpy(self.data[idx]).float()
        y = torch.from_numpy(np.array(self.labels[idx])).long()
        return x, y

train_dataset = dataset("Data/Dataset/train.npy")
val_dataset = dataset("Data/Dataset/Validation.npy")

batch_size = 32
train_loader = DataLoader(train_dataset, batch_size=batch_size, shuffle=True)
val_loader = DataLoader(val_dataset, batch_size=batch_size, shuffle=False)


# 检查GPU可用性
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
model = FNN().to(device)

# 定义损失函数和优化器
criterion = nn.CrossEntropyLoss()
optimizer = optim.Adam(model.parameters(), lr=0.001)


# 训练参数
num_epochs = 50
loss0=np.zeros((2,num_epochs))

save_path = "Model/model.pth"

# 训练循环
for epoch in range(num_epochs):
    # 训练阶段
    model.train()
    train_loss, train_correct = 0.0, 0
    for inputs, labels in tqdm(train_loader, desc=f"Epoch {epoch+1}/{num_epochs} [Train]"):
        inputs, labels = inputs.to(device), labels.to(device)
        
        optimizer.zero_grad()
        outputs = model(inputs)
        loss = criterion(outputs, labels)
        loss.backward()
        optimizer.step()
        
        train_loss += loss.item()
        _, predicted = torch.max(outputs.data, 1)
        train_correct += (predicted == labels).sum().item()
    
    train_loss /= len(train_loader)
    loss0[0,epoch]=train_loss
    train_acc = 100 * train_correct / len(train_dataset)

    # 验证阶段
    model.eval()
    val_loss, val_correct = 0.0, 0
    with torch.no_grad():
        for inputs, labels in tqdm(val_loader, desc=f"Epoch {epoch+1}/{num_epochs} [Val]"):
            inputs, labels = inputs.to(device), labels.to(device)
            
            outputs = model(inputs)
            loss = criterion(outputs, labels)
            val_loss += loss.item()
            
            _, predicted = torch.max(outputs.data, 1)
            val_correct += (predicted == labels).sum().item()
    
    val_loss /= len(val_loader)
    loss0[1,epoch]=val_loss
    val_acc = 100 * val_correct / len(val_dataset)

    # 打印日志
    print(f"Epoch {epoch+1}/{num_epochs}: "
          f"Train Loss: {train_loss:.4f}, Acc: {train_acc:.2f}% | "
          f"Val Loss: {val_loss:.4f}, Acc: {val_acc:.2f}%")

np.save("Model/loss.npy",loss0)
torch.save(model.state_dict(), save_path)

print("Training completed!")