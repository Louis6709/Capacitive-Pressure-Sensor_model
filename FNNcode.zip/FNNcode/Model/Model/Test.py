import torch
import numpy as np
from FnnModel import FNN
import torch.nn.functional as F 


device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
test_correct=0
test=np.load(r"../../DataCode/DataCode/Dataset/test.npy")[:,:10]
label=np.load(r"../../DataCode/DataCode/Dataset/test.npy")[:,10]
test=torch.from_numpy(test).float().to(device)
label=torch.from_numpy(label).long().to(device)


model = FNN().to(device)
model.load_state_dict(torch.load(r"./model.pth",weights_only=True))
model.eval()
with torch.no_grad():
    outputs=model(test)

_, predicted = torch.max(outputs.data, 1)
test_correct += (predicted == label).sum().item()
print(F.softmax(outputs))
print(f"测试准确率：{test_correct/test.shape[0] *100}%")


